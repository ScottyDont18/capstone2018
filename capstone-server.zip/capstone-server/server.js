//Express required for network management. body-parser to unpack POST payload.
const express = require('express');
const JSONParser = require('body-parser');
const app = express();

//Tell the express app how to parse body-content
app.use(JSONParser.urlencoded({extended:true}));

//Create mongoDB object for later database connection
var MongoClient = require('mongodb').MongoClient;
//URI to mongodb atlas database
var uri = "mongodb://admin:T3IQQMYbkexCkj3c@cluster0-shard-00-00-hbm2h.gcp.mongodb.net:27017,cluster0-shard-00-01-hbm2h.gcp.mongodb.net:27017,cluster0-shard-00-02-hbm2h.gcp.mongodb.net:27017/traingingmodules?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin";

//Code to create get server for previous connectivity testing
/*app.get('/', (req, res) => {
	res.status(200).send('Server is Up').end()
});*/

//Node js server creates route to /testInsert page if requested by POST method
app.post('/testInsert', (req, res) => {	
	//Unpack payload's body into workable object
	var insertModuleJSON = JSON.parse(Object.keys(req.body)[0]);
	//Insert payload content in variables for later insertion
	var moduletitle = insertModuleJSON.moduletitle;
	var moduletext = insertModuleJSON.modulecontent;
	
	//Connect to mongoDB atlas database
	MongoClient.connect(uri, function(err, client) {
		//If statement if connection fails
	   if(err)
		{
			console.log(err);
		}
		else {
			console.log ("Connection Successful")
		}
		//Perform basic single insert into 'trainingModules' database and 'modules' collection
		client.db("trainingModules").collection("modules").insertOne({name:moduletitle, contenttext:moduletext},function(err, res){
			//If statement incase insertion fails
			if (err){
				console.log(err);
			}
			else{
				console.log("Insert Success");
			}
			client.close();
		});
		res.end();
	});
});

//start server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
	console.log('Server was hit');
});
