//Express required for network management. body-parser to unpack POST payload.
const express = require('express');
const JSONParser = require('body-parser');
const app = express();
const dialogflow = require('dialogflow');
const uuid = require('uuid');

//Tell the express app how to parse body-content
app.use(JSONParser.urlencoded({extended:true}));

//Create mongoDB object for later database connection
var MongoClient = require('mongodb').MongoClient;
//URI to mongodb atlas database
var uri = "mongodb://admin:T3IQQMYbkexCkj3c@cluster0-shard-00-00-hbm2h.gcp.mongodb.net:27017,cluster0-shard-00-01-hbm2h.gcp.mongodb.net:27017,cluster0-shard-00-02-hbm2h.gcp.mongodb.net:27017/traingingmodules?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin";

//Code to create get server for previous connectivity testing
/*app.get('/', (req, res) => {
	//res.status(200).send('Test Page Up').end()
	//createEntity('capstone-220605','TypeTest3','KIND_MAP',['testThree',['AnotherArray'],'testFour',['YetAnother?']]);
	//createIntent('capstone-220605','TestIntent',['Where am I?','Who are you?'],['We are everywhere','In the end, we are all']);
	sendSentence('capstone-220605', 'hello', res);
});*/

//Listen for sentence input
app.post('/sendSentence', (req, res) => {
	//Unpack payload's body into workable object
	var payloadJSON = JSON.parse(Object.keys(req.body)[0]);
	//Insert payload content in variables for later insertion
	var sentenceString = payloadJSON.sentenceString;
	sendSentence('capstone-220605', sentenceString, res);
});
//Function that handles sentence exchange, sends response to client through serverResponse arguement
async function sendSentence(projectId, sentenceString, serverResponse) {
  var sessionId = uuid.v4();
  var sessionClient = new dialogflow.SessionsClient();
  var sessionPath = sessionClient.sessionPath(projectId, sessionId);

  var request = {
    session: sessionPath,
    queryInput: {
      text: {
        text: sentenceString,
        languageCode: 'en-US',
      },
    },
  };


  var responses = await sessionClient.detectIntent(request);
  var result = responses[0].queryResult;
  serverResponse.json(result);
}
//Read through all existing modules.
app.post('/readModules', (req, res) => {
	queryFindAll(function(err,result){
		console.log(result);
		res.json(result);
	});
	
});
//Handle mongoDB client query
function queryFindAll(callback){
	MongoClient.connect(uri, function(err, client) {
		//If statement if connection fails
	   if(err)
		{
			console.log(err);
		}
		else {
			console.log ("Connection Successful")
		}
		client.db("trainingModules").collection("modules").find({}).toArray(function(err,result){
			if (err){
				console.log(err);
			}
			else{
				console.log("Search Success");
			}
			callback(null,result);
			client.close();
		});
	});
}

//Node js server creates route to /testInsert page if requested by POST method
app.post('/testInsert', (req, res) => {	
	//Unpack payload's body into workable object
	var insertModuleJSON = JSON.parse(Object.keys(req.body)[0]);
	//Insert payload content in variables for later insertion
	var moduletitle = insertModuleJSON.moduletitle;
	var moduletext = insertModuleJSON.modulecontent;
	
	//Connect to mongoDB atlas database
	MongoClient.connect(uri, function(err, client) {
		//If statement if connection fails
	   if(err)
		{
			console.log(err);
		}
		else {
			console.log ("Connection Successful")
		}
		//Perform basic single insert into 'trainingModules' database and 'modules' collection
		client.db("trainingModules").collection("modules").insertOne({name:moduletitle, contentText:moduletext, moduleStatus:"Current"},function(err, res){
			//If statement incase insertion fails
			if (err){
				console.log(err);
			}
			else{
				console.log("Insert Success");
			}
			client.close();
		});
		res.end();
	});
});
//Listen for entity creations
app.post('/createEntity', (req,res) => {
	res.sendStatus(200);
	//Unpack payload's body into workable object
	var payloadJSON = JSON.parse(Object.keys(req.body)[0]);
	var entityName = payloadJSON.entityName;
	var entitySyns = (payloadJSON.entitySyns).split(",");
	var entitiesArray = [payloadJSON.entityWord, entitySyns];
	createEntity('capstone-220605',entityName,'KIND_MAP',entitiesArray);
});
//Listen for intent creations
app.post('/createIntent', (req,res) => {
	res.sendStatus(200);
	//Unpack payload's body into workable object
	var payloadJSON = JSON.parse(Object.keys(req.body)[0]);
	var intentName = payloadJSON.intentName;
	var phrasesArray = (payloadJSON.intentTrainingPhrases).split(",");
	var messagesArray = (payloadJSON.intentResponses).split(",");
	createIntent('capstone-220605',intentName,phrasesArray,messagesArray);
});
//Send client list of existing intents and entities
app.post('/listChatbotIntentAndEntities', (req,res) => {
	listBotDetails('capstone-220605', res);
});
//Send client details of specific entity 
app.post('/listEntityDetails', (req,res) => {
	//Unpack payload's body into workable object
	var payloadJSON = Object.keys(req.body)[0];
	var entityId = payloadJSON;
	listEntityDetails('capstone-220605', entityId, res);
});
//Listen for request to edit entity
app.post('/editEntity', (req,res) => {
	res.sendStatus(200);
	//Unpack payload's body into workable object
	var payloadJSON = JSON.parse(Object.keys(req.body)[0]);
	var entityId = payloadJSON.entityId;
	var entityName = payloadJSON.entityName;
	var entityWord = payloadJSON.entityWord;
	var entitySyns = (payloadJSON.entitySyns).split(",");
	var entitiesArray = [payloadJSON.entityWord, entitySyns];
	editEntity('capstone-220605',entityId,entityWord,entityName,'KIND_MAP',entitiesArray);
});
//Listen for request to edit intent
app.post('/editIntent', (req,res) => {
	res.sendStatus(200);
	//Unpack payload's body into workable object
	var payloadJSON = JSON.parse(Object.keys(req.body)[0]);
	var intentName = payloadJSON.intentName;
	var phrasesArray = (payloadJSON.intentTrainingPhrases).split(",");
	var messagesArray = (payloadJSON.intentResponses).split(",");
});

//start server/setup ports to listen on
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
	console.log('Server was hit');
});

/*
The following functions are from the nodejs dialogflow package, declared as a constant at start of file.
The repo for these functions are found here: https://github.com/googleapis/nodejs-dialogflow
The below functions retain the specific object setup/parameters in order to talk to the dialogflow service,
but also contain additional arguments and altered code in order to pass data to requesting clients.
*/

/*This function is a combination of the base createEntityType and createEntity functions
Dialogflow treats the name of an entity as a separate object 'type'.
Future functions and improvements need to consider entities with more than one 'word', or sub-entities.
The createEntity function below only supports entity creation of a single entity type, one word and many synonyms*/
async function createEntity(projectId, displayName, kind, entitiesList) {
  // Instantiates clients
  var entityTypesClient = new dialogflow.EntityTypesClient();

  // The path to the agent the created entity type belongs to.
  var agentPath = entityTypesClient.projectAgentPath(projectId);
  //JSONobject sent to dialogflow
  var createEntityTypeRequest = {
    parent: agentPath,
    entityType: {
      displayName: displayName,
      kind: kind,
    },
  };
  //The await command is key, otherwise the server will continue trying to create an entity before it even exists.
  var responses = await entityTypesClient.createEntityType(createEntityTypeRequest);
  //Figure out the entity type's ID so its contents can be built.
  var entityId = responses[0].name;
  entityId = entityId.split("/")
  entityTypeId = entityId[entityId.length-1];
  //New path, since the contents are children of entitytype.
  agentPath = entityTypesClient.entityTypePath(projectId, entityTypeId);
  //Build the entity's contents.
  var arrayOfEntities = []
  var entity;
  
  for (i = 0; i < entitiesList.length; i+= 2){
	entity = {
		value: entitiesList[i],
		synonyms: entitiesList[i+1],
	};
	arrayOfEntities.push(entity);
  }

  var createEntitiesRequest = {
    parent: agentPath,
    entities: arrayOfEntities,
  };
  //Wait for dialogflow service to respond after entity has been created.
  //Storing these responses in a single var or array can be useful when debugging, makes it easier to send attributes to console.log functions.
  var [response] = await entityTypesClient.batchCreateEntities(createEntitiesRequest);
}
//Creating intents have the same handshaking mechanisms as creating entities, but lack an 'intentType'
//Instead, intent names, trainingPhrases and messages (responses) are all in the same JSONobject/same level

/*
Currently infeasible to editIntents at this time. Dialogflow only returns name and messages
when it is requested. The current nodejs dialogflow library returns empty trainingPhrase arrays
even when these intents are populated. Proper json files can be downloaded from the agent's console
directly but cannot be accessed programmatically at this time.

Only the create intent functionality can work since it does not rely on preserving trainingPhrase data of previous intents.
*/
async function createIntent(projectId, displayName, trainingPhrasesParts, messageTexts) {
	//Standard build path and client request to dialogflow
  var intentsClient = new dialogflow.IntentsClient();

  var agentPath = intentsClient.projectAgentPath(projectId);
	//Assemble training phrases for delivery to dialogflow
  var trainingPhrases = [];

  trainingPhrasesParts.forEach(trainingPhrasesPart => {
    var part = {
      text: trainingPhrasesPart,
    };

    var trainingPhrase = {
      type: 'EXAMPLE',
      parts: [part],
    };

    trainingPhrases.push(trainingPhrase);
  });
	//The sample code from the dialogflow github pages double encapsulates the messages
	//Dialogflow's 'RESTFul' API has proven finniky/throws errors when altering the data this library sends to dialogflow service.
  var messageText = {
    text: messageTexts,
  };

  var message = {
    text: messageText,
  };
	//Build intent itself, then request to create intent
  var intent = {
    displayName: displayName,
    trainingPhrases: trainingPhrases,
    messages: [message],
  };

  var createIntentRequest = {
    parent: agentPath,
    intent: intent,
  };

  //Wait for confirmation.
  var responses = await intentsClient.createIntent(createIntentRequest);
}
//Based on the projectId, get 'details' of the bot. This builds a list of intents and entities that currently existing
async function listBotDetails(projectId, res) {
	//Build client to connect to dialogflow
  var entityTypesClient = new dialogflow.EntityTypesClient();

  var agentPath = entityTypesClient.projectAgentPath(projectId);

  var requestEntities = {
    parent: agentPath,
  };
	//Wait for response
  var [responseEntities] = await entityTypesClient.listEntityTypes(requestEntities);
  //Repeat process for intents
  var intentsClient = new dialogflow.IntentsClient();
  
  agentPath = intentsClient.projectAgentPath(projectId);

  var requestIntents = {
    parent: agentPath,
  };
  
  var [responseIntents] = await intentsClient.listIntents(requestIntents);
  //Take gathered intents and entities, put them into json package that client can read.
  res.json({'entitiesList':responseEntities,'intentsList':responseIntents});
}
//Function that gets the details of a specific entity, based on projectId and entityId
//Similar to the generic list function above, but for specific entities instead of a 'findall' call.
//This is used to populate the fields of the EditEntity activity on the android app.
async function listEntityDetails(projectId, entityTypeId, res) {
  var entityTypesClient = new dialogflow.EntityTypesClient();

  var entityTypePath = entityTypesClient.entityTypePath(
    projectId,
    entityTypeId
  );

  var request = {
    name: entityTypePath,
  };

  var [response] = await entityTypesClient.getEntityType(request);

  res.json({'entityDetails':response});
}
//The dialogflow nodejs library only has operations for create, list and delete.
//This is an improved 'update' method that performs the delete, create entityType and then create entity functionality all in one call.
async function editEntity(projectId, entityTypeId, entityValue, displayName, kind, entitiesList) {

	/*
	Important Note: Delete entity type does not delete the entity contents it stored.
	Always delete the content of the entity first, then remove the entity type.
	Otherwise the entity needs to be deleted manually through the dialogflow console.
	*/

  // Instantiates clients
  var entityTypesClient = new dialogflow.EntityTypesClient();

  // The path to the agent the entity belongs to.
  var entityTypePath = entityTypesClient.entityTypePath(
    projectId,
    entityTypeId
  );

  var request = {
    parent: entityTypePath,
    entityValues: [entityValue],
  };
	//Wait for confirmation entity contents has been deleted
  var responses = await entityTypesClient.batchDeleteEntities(request);
  //Start new client for entity type deletion
  entityTypesClient = new dialogflow.EntityTypesClient();

  entityTypePath = entityTypesClient.entityTypePath(
    projectId,
    entityTypeId
  );

  request = {
    name: entityTypePath,
  };

  // Call the client library to delete the entity type.
  responses = await entityTypesClient.deleteEntityType(request);
  
  // Instantiates new client call for entity creation
  entityTypesClient = new dialogflow.EntityTypesClient();

  // The path to the agent the created entity type belongs to.
  var agentPath = entityTypesClient.projectAgentPath(projectId);

  var createEntityTypeRequest = {
    parent: agentPath,
    entityType: {
      displayName: displayName,
      kind: kind,
    },
  };
	//Wait for entityType to be created.
  responses = await entityTypesClient.createEntityType(createEntityTypeRequest);
  //Build entity contents based off of created entityId from the entityType.
  var entityId = responses[0].name;
  entityId = entityId.split("/")
  entityTypeId = entityId[entityId.length-1];
  
  agentPath = entityTypesClient.entityTypePath(projectId, entityTypeId);
  
  var arrayOfEntities = []
  var entity;
  
  for (i = 0; i < entitiesList.length; i+= 2){
	entity = {
		value: entitiesList[i],
		synonyms: entitiesList[i+1],
	};
	arrayOfEntities.push(entity);
  }

  var createEntitiesRequest = {
    parent: agentPath,
    entities: arrayOfEntities,
  };
//Wait for entity content population.
  var [response] = await entityTypesClient.batchCreateEntities(createEntitiesRequest);
}
