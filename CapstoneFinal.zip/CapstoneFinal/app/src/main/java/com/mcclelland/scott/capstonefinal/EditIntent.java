package com.mcclelland.scott.capstonefinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EditIntent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_intent);
    }
}
