package com.mcclelland.scott.capstonefinal;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class TalkToChatbot extends AppCompatActivity {
    ArrayList conversationStorage = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talk_to_chatbot);

        findViewById(R.id.btnSendSentence).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                EditText fieldSentenceInput = findViewById(R.id.fieldSentenceInput);
                //Get data
                String fieldSentenceString = fieldSentenceInput.getText().toString();
                fieldSentenceInput.setText("");
                conversationStorage.add(fieldSentenceString);
                //Convert strings to JSON format for easier parsing on backend
                JSONObject json = new JSONObject();
                try {
                    json.put("sentenceString", fieldSentenceString);
                }catch (JSONException e){
                    throw new RuntimeException(e);
                }
                //Execute post request to node js server
                new ManageConversation().execute(json.toString());

            }
        });
    }

    private class ManageConversation extends AsyncTask<String, Void, String> {
        TextView conversationList = (TextView)findViewById(R.id.textFieldChatOutput);
        @Override
        protected String doInBackground(String... params){
            String responsePayloadString = "Failure";

            try {
                //Instantiate connection to node js middleware server
                URL url = new URL("https://capstone-220605.appspot.com/sendSentence");
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();

                //urlConnection.setRequestProperty("Content-Type", "application/json");
                //urlConnection.setRequestProperty("Accept", "application/json");

                //Declare request method to be of type 'POST'
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                //Instantiate outputstream and buffered writer objects to write content to the POST request
                OutputStream outputStream = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                writer.write(params[0]);
                writer.flush();
                writer.close();

                //After writing is complete, connect and send request to server.
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == 200){
                    InputStream inputStream = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
                    StringBuilder stringBuilder = new StringBuilder();
                    responsePayloadString = "";
                    while ((responsePayloadString = reader.readLine()) != null){
                        stringBuilder.append(responsePayloadString);
                    }
                    responsePayloadString = stringBuilder.toString();
                    inputStream.close();
                }
                outputStream.close();
                urlConnection.disconnect();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }

            return responsePayloadString;
        }

        protected void onPostExecute(String payload){
            try {
                JSONObject jsonArray = new JSONObject(payload);
                conversationStorage.add(jsonArray.get("fulfillmentText"));
                String conversationBuildString = "";
                for (int i = 0; i < conversationStorage.size(); i++){
                    conversationBuildString += conversationStorage.get(i) + "\n";
                }
                conversationList.setText(conversationBuildString);
            }catch (JSONException e){
                throw new RuntimeException(e);
            }
        }

    }
}
