package com.mcclelland.scott.capstonefinal;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class EditChatbot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_chatbot);

        Button btnCreateIntent = (Button)findViewById(R.id.btnCreateIntent);
        Button btnCreateEntity = (Button)findViewById(R.id.btnCreateEntity);

        btnCreateIntent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToCreateIntent();
            }
        });
        btnCreateEntity.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToCreateEntity();
            }
        });

        new UpdateLists().execute();
    }

    private void sendToCreateIntent(){
        Intent i = new Intent(EditChatbot.this, CreateIntent.class);
        startActivity(i);
    }

    private void sendToCreateEntity(){
        Intent i = new Intent(EditChatbot.this, CreateEntity.class);
        startActivity(i);
    }

    private class UpdateLists extends AsyncTask<String, Void, String> {
        ListView listOfIntents = (ListView)findViewById(R.id.listOfIntents);
        ListView listOfEntities = (ListView)findViewById(R.id.listOfEntities);
        @Override
        protected String doInBackground(String... params){
            String responsePayloadString = "Failure";

            try {
                //Instantiate connection to node js middleware server
                URL url = new URL("https://capstone-220605.appspot.com/listChatbotIntentAndEntities");
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();

                //urlConnection.setRequestProperty("Content-Type", "application/json");
                //urlConnection.setRequestProperty("Accept", "application/json");

                //Declare request method to be of type 'POST'
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                //Instantiate outputstream and buffered writer objects to write content to the POST request
                OutputStream outputStream = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                writer.write("Send Payload");
                writer.flush();
                writer.close();

                //After writing is complete, connect and send request to server.
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == 200){
                    InputStream inputStream = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
                    StringBuilder stringBuilder = new StringBuilder();
                    responsePayloadString = "";
                    while ((responsePayloadString = reader.readLine()) != null){
                        stringBuilder.append(responsePayloadString);
                    }
                    responsePayloadString = stringBuilder.toString();
                    inputStream.close();
                }
                outputStream.close();
                urlConnection.disconnect();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }

            return responsePayloadString;
        }

        protected void onPostExecute(String payload){
            try {
                ArrayList intentAndroidList = new ArrayList();
                ArrayList entityAndroidList = new ArrayList();
                JSONObject jsonArray = new JSONObject(payload);
                JSONArray entitiesList = jsonArray.getJSONArray("entitiesList");
                JSONObject tempJSON;
                for (int i = 0; i < entitiesList.length(); i++){
                    tempJSON = entitiesList.getJSONObject(i);
                    entityAndroidList.add(tempJSON.get("displayName") + "\n" + tempJSON.get("name"));
                }
                JSONArray intentsList = jsonArray.getJSONArray("intentsList");
                for (int i = 0; i < intentsList.length(); i++){
                    tempJSON = intentsList.getJSONObject(i);
                    intentAndroidList.add(tempJSON.getString("displayName") + "\n" + tempJSON.getString("name"));
                }

                final ArrayAdapter intentsAdapter = new ArrayAdapter(EditChatbot.this, android.R.layout.simple_list_item_1, intentAndroidList);
                listOfIntents.setAdapter(intentsAdapter);
                listOfIntents.setOnItemClickListener(sendToEditIntent);

                final ArrayAdapter entitiesAdapter = new ArrayAdapter(EditChatbot.this, android.R.layout.simple_list_item_1, entityAndroidList);
                listOfEntities.setAdapter(entitiesAdapter);
                listOfEntities.setOnItemClickListener(sendToEditEntity);
            }catch (JSONException e){
                throw new RuntimeException(e);
            }
        }

    }

    private AdapterView.OnItemClickListener sendToEditIntent = new AdapterView.OnItemClickListener() {
        public void onItemClick (AdapterView av, View v, int arg2, long arg3) {
            String data = ((TextView) v).getText().toString();
            String[] dataCollection = data.split("\n");
            dataCollection = dataCollection[1].split("/");
            String intentId = dataCollection[dataCollection.length-1];
            Intent i = new Intent(EditChatbot.this, EditIntent.class);
            i.putExtra("intentId", intentId);
            startActivity(i);
        }
    };

    private AdapterView.OnItemClickListener sendToEditEntity = new AdapterView.OnItemClickListener() {
        public void onItemClick (AdapterView av, View v, int arg2, long arg3) {
            String data = ((TextView) v).getText().toString();
            String[] dataCollection = data.split("\n");
            dataCollection = dataCollection[1].split("/");
            String entityId = dataCollection[dataCollection.length-1];
            Intent i = new Intent(EditChatbot.this, EditEntity.class);
            i.putExtra("entityId", entityId);
            startActivity(i);
        }
    };
}
