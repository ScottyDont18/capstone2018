package com.mcclelland.scott.capstonefinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class CreateIntent extends AppCompatActivity {

    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_intent);

        final EditText fieldIntentName = findViewById(R.id.fieldIntentName);
        final EditText fieldIntentTrainingPhrases = findViewById(R.id.fieldIntentTraining);
        final EditText fieldIntentResponses = findViewById(R.id.fieldIntentResponses);

        findViewById(R.id.btnSendIntent).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //Get data
                String intentName = fieldIntentName.getText().toString();
                String intentTrainingPhrases = fieldIntentTrainingPhrases.getText().toString();
                String intentResponses = fieldIntentResponses.getText().toString();
                //Convert strings to JSON format for easier parsing on backend
                JSONObject json = new JSONObject();
                try {
                    json.put("intentName", intentName);
                    json.put("intentTrainingPhrases", intentTrainingPhrases);
                    json.put("intentResponses", intentResponses);
                }catch (JSONException e){
                    throw new RuntimeException(e);
                }
                //Execute post request to node js server
                new UploadIntent().execute(json.toString());

            }
        });
    }

    private class UploadIntent extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show(CreateIntent.this, "Creating Intent...", "Please Wait");
        }
        @Override
        protected String doInBackground(String... params){
            String successString = "Failure";

            try {
                //Instantiate connection to node js middleware server
                URL url = new URL("https://capstone-220605.appspot.com/createIntent");
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();

                //urlConnection.setRequestProperty("Content-Type", "application/json");
                //urlConnection.setRequestProperty("Accept", "application/json");

                //Declare request method to be of type 'POST'
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                //Instantiate outputstream and buffered writer objects to write content to the POST request
                OutputStream outputStream = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                //params[0] is the JSON object converted to string due to the createModule button press event
                writer.write(params[0]);
                writer.flush();
                writer.close();
                outputStream.close();
                //After writing is complete, connect and send request to server.
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();

                /*if (responseCode != 200){
                    System.out.println(responseCode);
                }*/

                urlConnection.disconnect();
                successString = "Success";
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }

            return successString;
        }
        @Override
        protected void onPostExecute(String successString){
            if (successString.equals("Success")){
                Toast.makeText(getApplicationContext(), "Intent Created", Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(getApplicationContext(), "Failure to Create Intent", Toast.LENGTH_LONG).show();
            }
            Intent i = new Intent();
            i.setClass(getApplicationContext(),MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }

    }
}
