package com.mcclelland.scott.capstonefinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCreateModule = (Button)findViewById(R.id.btnCreateModule);
        Button btnReviewModules = (Button)findViewById(R.id.btnReviewModules);
        Button btnEditChatbot = (Button)findViewById(R.id.btnEditChatBot);
        Button btnTalkToChatbot = (Button)findViewById(R.id.btnTalkToChatbot);

        btnCreateModule.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToCreateModule();
            }
        });

        btnReviewModules.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToReviewModule();
            }
        });

        btnEditChatbot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToEditChatbot();
            }
        });

        btnTalkToChatbot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                sendToTalkToChatbot();
            }
        });

    }

    private void sendToCreateModule(){
        Intent i = new Intent(MainActivity.this, CreateModule.class);
        startActivity(i);
    }

    private void sendToReviewModule(){
        Intent i = new Intent(MainActivity.this, ReviewModule.class);
        startActivity(i);
    }

    private void sendToEditChatbot(){
        Intent i = new Intent(MainActivity.this, EditChatbot.class);
        startActivity(i);
    }

    private void sendToTalkToChatbot(){
        Intent i = new Intent(MainActivity.this, TalkToChatbot.class);
        startActivity(i);
    }
}
